<?php

include("configdb.php");

try {
    $conn = new PDO(
        "mysql:host=$host;port=$port;dbname=$dbname;charset=utf8",$username,$password);

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "Conexao realizada com sucesso!";

} catch (PDOException $e) {
    echo "Erro na conexao: " . $e->getMessage();
}

?>
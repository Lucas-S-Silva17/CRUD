<?php
$host = "localhost";
$dbname = "teste";
$username = "root";
$password = "usbw";
$port = "3307";
?>
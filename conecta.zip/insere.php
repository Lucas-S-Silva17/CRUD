<?php

include("conecta.php");

try {

    $nome = $_POST['nome'] ?? '';
    $email = $_POST['email'] ?? '';

    if (empty($nome) || empty($email)) {
        echo "Preencha todos os campos!";
        exit;
    }

    $sql = "INSERT INTO login (nm_nome, ds_email)
            VALUES (:nome, :email)";

    $stmt = $conn->prepare($sql);

    $stmt->bindParam(':nome', $nome);
    $stmt->bindParam(':email', $email);

    $stmt->execute();

    echo "Cadastro realizado com sucesso!<br>";
    echo "Nome: $nome<br>";
    echo "Email: $email";

} catch (PDOException $e) {

    echo "Erro: " . $e->getMessage();

}
?>
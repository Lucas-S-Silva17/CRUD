<?php
include("conecta.php");
include("exibe_o.php");
try{
$sql = "INSERT INTO login (nm_nome, ds_email) VALUES (:nome, :email)";
$stmt = $conn->prepare($sql);

$nome = $_POST['#nome'];
$email = $_POST['#email'];

$stmt->bindParam(':nome', $nome);
$stmt->bindParam(':email', $email);

$stmt->execute();
echo "conexão";
echo "$nome,$email";
tabela();
} catch (PDOException $e) {
    echo "Erro na conexao: " . $e->getMessage();
}
?>
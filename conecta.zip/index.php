<?php
include("exibe_o.php");
?>
<html>

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@6.0.0-alpha.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-B/GM4XqrwHnWXNOWMbloTmrYXZg10cakYGmpfsR/bbzQ6JAJI4ihuyADKLnBgrCe" crossorigin="anonymous">
<script type="module" src="https://cdn.jsdelivr.net/npm/bootstrap@6.0.0-alpha.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-1a/pXj49ZQ1aHEmrJ+gMw1otqoVsYwlEnlD8mIfY2TV03r20Y0CN7uqx1tQogjPL" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

    <script>
        $(document).ready(function() {
            $('#botao').click(function() {

                var nome = $('#nome').val();
                var email = $('#email').val();
                var request = $.ajax({

                    url: "insere.php",
                    type: "POST",
                    data: {
                        nome: nome,
                        email: email
                    },
                    dataType: "html",
                    success: function(resposta) {
                        console.log(resposta);
                        tabela();
                    },
                    error: function(jqXHR, textStatus) {
                        console.log("Request failed: " + textStatus)
                    }
                });
            });
        });
    </script>
</head>

<body>

    <input type="text" name="nome" id="nome" placeholder="Nome"> <br>
    <input type="text" name="email" id="email" placeholder="Email"><br>
    <button id="botao">enviar</button>
    <div id="tabela"><?php tabela()
     ?></div>
</body>

</html>
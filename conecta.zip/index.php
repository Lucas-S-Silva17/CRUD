
<?php include("exibe_o.php");?>
<html>
<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
   
   <script>
        $(document).ready(function () {
            tabela();
            $('#botao').click(function () {
                var nome = $('#nome').val();
                var email = $('#email').val();
                var request = $.ajax({

                    url: "insere.php",
                    type: "POST",
                    data: "#nome=" + nome + "& #email=" + email,
                    dataType: "html"
                }).done(function (resposta) {
                    console.log(resposta);

                }).fail(function (jqXHR, textStatus) {
                    console.log("Request failed: " + textStatus);

                }).always(function () {
                    console.log("completou");
                    tabela();
                });
            });
        });
    </script>
</head>

<body>

    <input type="text" id="nome" placeholder="Nome"> <br>
    <input type="text" id="email" placeholder="Email"><br>
    <button id="botao">enviar</button> 
    <div> <?php tabela();
    ?></div>
</body>

</html>
<?php
$host = "localhost";
$dbname = "teste";
$username = "root";
$password = "";
$port = "3306";
?>
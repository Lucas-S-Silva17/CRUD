<?php

function tabela(){

    include("conecta.php");

    $sql = "SELECT * FROM login";
    $resultado = $conn->query($sql);


    while ($linha = $resultado->fetch(PDO::FETCH_ASSOC)) {
              echo '<section class="card" style="max-width: 320px">
  <img src="foto1.jpg" class="card-img-row" alt="...">
  <div class="card-body">
    <h4 class="card-title">Card title</h4>
    <p class="card-text">' . $linha['nm_nome'] . "<br>". $linha['ds_email'] . '.</p>
    <a href="#" class="btn-solid theme-primary">Editar</a>
    <a href="#" class="btn-solid theme-danger">Excluir</a>
  </div>
</section> <br>';
    }

}
?>
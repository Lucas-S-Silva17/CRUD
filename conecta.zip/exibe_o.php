<?php

function tabela(){

    include("conecta.php");

    $sql = "SELECT * FROM login";
    $resultado = $conn->query($sql);

    echo "<table border='1'>";
    echo "<tr>";
    echo "<th>Nome</th>";
    echo "<th>Email</th>";
    echo "</tr>";

    while ($linha = $resultado->fetch(PDO::FETCH_ASSOC)) {

        echo "<tr>";
        echo "<td>" . $linha['nm_nome'] . "</td>";
        echo "<td>" . $linha['ds_email'] . "</td>";
        echo "</tr>";

    }

    echo "</table>";
}
?>
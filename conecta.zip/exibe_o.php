<?php
function tabela(){
include("conecta.php");

$sql = "SELECT * FROM login";
$resultado = $conn->query($sql);

while ($linha = $resultado->fetch(PDO::FETCH_ASSOC)) {
    echo "<pre>";
    print_r($linha);
    echo "</pre>";
}
};
?>